package tw.zerojudge.Server.Configs;

public class Config {

}
